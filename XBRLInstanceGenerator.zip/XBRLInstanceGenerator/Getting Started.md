# 1. Project
***Project name***: XBRLInstanceGenerator

***Description***:
    This service/component is responsible for converting XBRL instances. 
    The input file is an Excel file in Fujitsu format. 
    Conversion is possible to both XML and CSV. 
    Currently, conversion to CSV is possible through an intermediate XML format.

## 2. Documentation

The project documentation is divided into two documents.

### 2.1 Swagger

   contains a description of endpoints and models.

### 2.2 This document

This document will contain more general information, such as the tasks for this service and how to start it.

### 2.1 Requirements

To run the project correctly, Docker and/or a remote code repository must be installed, 
depending on the method of starting the service.

### 2.2 How to start the service

Docker is used in the project. 
The preferred method is to download a ready-made image from a remote image repository. 
However, if such a repository is inaccessible or downloading is not possible, the project can be built using Docker.

#### 2.2.1 Remote image repository
The required file is docker-compose-image.yaml. 
The path to the image must be specified in the 'image' field. 
If everything is correct, use the command to run Docker:

```
docker-compose -f docker-compose-image.yaml up -d
```

the parameter -d is optional, it is used to run the container in the background.

#### 2.2.2 Remote image repository is inaccessible or an image cannot be downloaded

In this case, the entire project with source code must be provided. 
This can be done using Git/BitBucket/Azure Dev - if a remote code repository exists or by uploading. 
It is important that all code with all files is available. 
Use the appropriate command to build the image. 
The command must be executed in the directory where the Dockerfile is located.

``` 
docker-compose -f docker-compose.yaml build --no-cache
```

Once the image is built correctly, it should be available and ready to use.

To run the container, use the command:

``` 
docker-compose -f docker-compose.yaml up -d
```


### 2.3 Settings
You can find the application settings in the properties file. 
A properties file is a file with the extension *.properties. 
The file(s) must be located in the path: src/main/resources.
Spring Boot requires such a file for the application to run correctly.

All properties that start with ```log4j``` pertain to logging functions. 
Settings that start with ```spring``` usually pertain to application settings, or those that start with ```server```.
Meanwhile, the remaining ones are mainly settings related to the application's functionality and the logic it executes.

### 2.3.1 internal properties

```xbrlinstance.converter.saveOption```
This properties is responsible for enabling or disabling option of saving the intermediate file.
There are two possible values:
 - SAVE_INTERMEDIATE_IF_ERROR
     This option determines whether the intermediate file should be saved if an error occurs during the conversion process.
 - ONLY_TARGET
   If during the conversion from Xlsx to CSV the process fails due to the conversion from XML to CSV, 
   this setting will prevent the intermediate file from being saved.

## 3. Troubleshooting

### 3.1 Taxonomy not found

If a 403 'Resource not found' error occurs when attempting to download a taxonomy, 
it means that either the taxonomy has not been uploaded or the folder containing the taxonomy is not mounted.

```
Downloading file http://www.eba.europa.eu/eu/fr/xbrl/crr/fws/corep/its-005-2020/2022-03-01/mod/corep_of.xsd from Internet
ERROR 151 --- [xbrl-instance-generator] [nio-8090-exec-7] api.service.EntityResolverService        : File http://www.eba.europa.eu/eu/fr/xbrl/crr/fws/corep/its-005-2020/2022-03-01/mod/corep_of.xsd not found
ERROR 151 --- [xbrl-instance-generator] [nio-8090-exec-7] a.controller.CentralControllerHandler    : java.io.IOException: Server returned HTTP response code: 403 for URL: https://www.eba.europa.eu/eu/fr/xbrl/crr/fws/corep/its-005-2020/2022-03-01/mod/corep_of.xsd

```


### 3.2 License file not found

The Application is failing to start because the license file is not found.
It could be caused by incorrect path to the license file or the file is not mounted.

```

