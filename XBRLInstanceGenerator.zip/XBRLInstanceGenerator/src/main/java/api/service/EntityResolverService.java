package api.service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fujitsu.xml.xbrl.xwand.processor.XBRLEntityResolver;

@Service
public class EntityResolverService implements XBRLEntityResolver {
	private static final Logger logger = LoggerFactory.getLogger(EntityResolverService.class);
	private FileService fileService;
	private String localRepositoryPath;

	public EntityResolverService(FileService fileService, @Value("${localRepository.path}") String localRepositoryPath) {
		this.fileService = fileService;
		this.localRepositoryPath = localRepositoryPath;
		if(Files.exists(Path.of(localRepositoryPath))){
			logger.warn("Local repository path does not exist: {}", localRepositoryPath);
		}
	}

	public FileService getFileService() {
		return fileService;
	}

	public void setFileService(FileService fileService) {
		this.fileService = fileService;
	}

	public String getLocalRepositoryPath() {
		return localRepositoryPath;
	}

	public void setLocalRepositoryPath(String localRepositoryPath) {
		this.localRepositoryPath = localRepositoryPath;
	}

	@Override
	public Result resolveOutputEntity(String nameSpace, String sysId) {
		return null;
	}

	@Override
	public Source resolveInputEntity(String nameSpace, String fileURI) {
		File file;
		try {
			file = findFileInRepository(fileURI);
			return new StreamSource(file);
		} catch (FileNotFoundException e) {
			return null;
		}
	}

	private String generateRepositoryPathFromURL(String url) {
		return localRepositoryPath + StringUtils.substringAfter(url, "/");
	}

	public File findFileInRepository(String fileURI) throws FileNotFoundException {

		logger.info("Resolving file: {}", fileURI);
		logger.info("Local repository path: {}", localRepositoryPath);
		String replace = localRepositoryPath + fileURI.replace("http://", "").replace("https://", "");
		logger.info("converted file path: {}", replace);
		String repositoryFilePath;
		if (fileURI.toLowerCase().startsWith("file")) {
			logger.info("File starts with file: {}", fileURI);
			fileURI = FilenameUtils.separatorsToSystem(fileURI);
			return new File(StringUtils.substringAfter(fileURI, "file:///"));
		} else if (fileURI.startsWith("http")) {
			logger.info("File starts with http: {}", fileURI);
			repositoryFilePath = generateRepositoryPathFromURL(fileURI);
		} else if (fileURI.replace("\\", "/").contains("/http/")) {
			repositoryFilePath = localRepositoryPath + "/" + StringUtils.substringAfter(fileURI.replace("\\", "/"), "/http/");
		} else {
			logger.info("File not resolvable: {}", fileURI);
			throw new FileNotFoundException(fileURI);
		}

		File file = new File(FilenameUtils.separatorsToSystem(repositoryFilePath));
		try {

			if (!file.exists()) {
				logger.warn("File {} not found in repository", fileURI);
				fileURI = FilenameUtils.separatorsToSystem(fileURI);
				if ((new File(fileURI.replace("file:///", "")).exists())) {
					logger.info("Copying file {} to repository", fileURI);
					file = fileService.copyToRepository(fileURI, repositoryFilePath);
				} else if (fileURI != null) {
					// If the "http type" file is not in the repository, we try to download it from internet
					logger.info("Downloading file {} from Internet", fileURI);
					file = fileService.downloadToTaxonomyRepository(fileURI, repositoryFilePath);
				}
			}

			return file;
		} catch (IOException e) {
			logger.error("File {} not found", fileURI);
			throw new FileNotFoundException(fileURI);
		}
	}

}
