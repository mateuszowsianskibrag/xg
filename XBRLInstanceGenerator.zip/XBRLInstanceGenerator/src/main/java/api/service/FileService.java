package api.service;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.validator.routines.UrlValidator;
import org.springframework.stereotype.Service;

/**
 * Service class for file management
 *
 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
 */
@Service
public class FileService {

	/**
	 * @param fetchUrl
	 * @param outputPath
	 * @return
	 * @throws FileNotFoundException
	 * @throws MalformedURLException
	 * @throws IOException
	 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
	 */
	public File downloadToTaxonomyRepository(String fetchUrl, String outputPath) throws MalformedURLException, FileNotFoundException, IOException {
		HttpURLConnection connection = getConnection(fetchUrl);
		BufferedInputStream in = new BufferedInputStream(connection.getInputStream());
		File outputDirectory = new File(outputPath.substring(0, outputPath.replace("/", "\\").lastIndexOf("\\")));
		if (!outputDirectory.exists()) {
			outputDirectory.mkdirs();
		}

		OutputStream out = new BufferedOutputStream(new FileOutputStream(new File(outputPath)));
		byte[] buf = new byte[256];
		int n = 0;
		while ((n = in.read(buf)) >= 0) {
			out.write(buf, 0, n);
		}
		out.flush();
		out.close();
		connection.disconnect();
		return new File(outputPath);
	}

	/**
	 * Get a connection from a file URL
	 *
	 * @param fetchUrl
	 * @return
	 * @throws MalformedURLException
	 * @throws FileNotFoundException
	 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
	 */
	private HttpURLConnection getConnection(String fetchUrl) throws IOException {
		UrlValidator urlValidator = new UrlValidator();
		// Validating URL
		if (!urlValidator.isValid(fetchUrl)) {
			throw new MalformedURLException("Malformed URL: " + fetchUrl);
		}

		HttpURLConnection connection;
		URL url = new URL(fetchUrl);
		url = getFinalURL(url);
		try {
			connection = (HttpURLConnection) url.openConnection();

			connection.setConnectTimeout(5000);

			connection.setUseCaches(false);
			connection.setDoOutput(false);

			connection.setRequestProperty("Content-Type", "text/xml");
			return connection;

		} catch (IOException e) {
			throw new FileNotFoundException(fetchUrl);
		}

	}

	public File copyToRepository(String inputPath, String outputPath) throws IOException {
		InputStream inputStream = null;
		OutputStream outputStream = null;

		File inputFile = new File(inputPath.replace("file:///", ""));
		if (!inputFile.exists()) {
			throw new FileNotFoundException(inputPath);
		}

		File outputDirectory = new File(outputPath.substring(0, outputPath.replace("/", "\\").lastIndexOf("\\")));
		if (!outputDirectory.exists()) {
			outputDirectory.mkdirs();
		}

		File outputFile = new File(outputPath);
		inputStream = new FileInputStream(inputFile);
		outputStream = new FileOutputStream(outputFile);

		byte[] buffer = new byte[1024];

		int length;
		while ((length = inputStream.read(buffer)) > 0) {
			outputStream.write(buffer, 0, length);
		}

		inputStream.close();
		outputStream.close();

		return outputFile;
	}

	private static URL getFinalURL(URL url) throws IOException {
		//check if the file wasn't moved
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		con.setInstanceFollowRedirects(false);
		con.connect();
		int resCode = con.getResponseCode();
		if (resCode == HttpURLConnection.HTTP_SEE_OTHER
				|| resCode == HttpURLConnection.HTTP_MOVED_PERM
				|| resCode == HttpURLConnection.HTTP_MOVED_TEMP) {
			String Location = con.getHeaderField("Location");
			if (Location.startsWith("/")) {
				Location = url.getProtocol() + "://" + url.getHost() + Location;
			}
			return getFinalURL(new URL(Location));
		}
		return url;
	}
}
