package api.service.processor.v2;

import api.service.processor.handler.SheetMappingErrorHandlerImpl;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingException;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingProcessor;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingProcessorFactory;

import javax.xml.transform.stream.StreamSource;

public final class FujitsuXlsxProcessor {

    private FujitsuXlsxProcessor() {}
    /**
     * Getting processor for Excel sheep mapping
     *
     * @param mappingFilePath
     * @return
     * @throws SheetMappingException
     * @last_modification: May 5, 2014
     * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
     */
    public static SheetMappingProcessor createNewInstance(SheetMappingErrorHandlerImpl sheetMappingErrorHandlerImpl, String mappingFilePath) throws SheetMappingException {

        SheetMappingProcessor sheetMappingProcessor = SheetMappingProcessorFactory.newInstance().newMappingProcessor(new StreamSource(mappingFilePath));
        sheetMappingProcessor.setErrorHandler(sheetMappingErrorHandlerImpl);
        sheetMappingProcessor.setPropertyMappingValue("CompanyName", "Latvijas  Banka");

        return sheetMappingProcessor;
    }
}
