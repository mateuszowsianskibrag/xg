package api.service.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class UnitCleanerHelper extends AbstractXBRLHelper
    {
    public static void cleanUnusedUnits(String xbrlInstanceFilePath) throws SAXException, IOException, ParserConfigurationException, TransformerException
	{
	Document document = readXMLDocument(xbrlInstanceFilePath);
	Set<String> usedUnitIds = findUsedUnitIds(new File(xbrlInstanceFilePath));
	if (usedUnitIds.isEmpty())
	    return;
	Node xbrlNode = document.getElementsByTagName("xbrli:xbrl").item(0);

	for (int i = 0; i < xbrlNode.getChildNodes().getLength(); i++)
	    {
	    Node node = xbrlNode.getChildNodes().item(i);
	    if (node.getNodeName().equals("xbrli:unit") && !usedUnitIds.contains(node.getAttributes().getNamedItem("id").getNodeValue()))
		{
		xbrlNode.removeChild(node);
		}
	    }
	normalizeDocument(xbrlNode);
	writeToXMLFile(document, xbrlInstanceFilePath);
	}

    private static Set<String> findUsedUnitIds(File xmlFile) throws IOException
	{
	FileInputStream fileInputStream = new FileInputStream(xmlFile);
	String[] unitIds = StringUtils.substringsBetween(IOUtils.toString(fileInputStream), "unitRef=\"", "\"");
	if (unitIds == null)
	    return Collections.<String> emptySet();
	Set<String> usedUnitIds = new HashSet<>(Arrays.asList(unitIds));
	fileInputStream.close();
	return usedUnitIds;
	}

    }
