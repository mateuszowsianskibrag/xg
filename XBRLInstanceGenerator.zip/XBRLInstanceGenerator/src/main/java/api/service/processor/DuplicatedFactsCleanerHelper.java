package api.service.processor;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class DuplicatedFactsCleanerHelper extends AbstractXBRLHelper
    {
    public static void cleanDuplicatedFacts(String xbrlInstanceFilePath) throws SAXException, IOException, ParserConfigurationException, TransformerException
	{
	Document document = readXMLDocument(xbrlInstanceFilePath);
	Set<String> facts = new HashSet<>();

	Node xbrlNode = document.getElementsByTagName("xbrli:xbrl").item(0);
	for (int i = 0; i < xbrlNode.getChildNodes().getLength(); i++)
	    {
	    Node node = xbrlNode.getChildNodes().item(i);

	    if (!isFact(node))
		continue;

	    trimFactValue(node);

	    String factKey = getFactKey(node);
	    if (facts.contains(factKey))
		{
		xbrlNode.removeChild(node);
		}
	    else
		facts.add(factKey);
	    }

	normalizeDocument(xbrlNode);
	writeToXMLFile(document, xbrlInstanceFilePath);
	}

    private static void trimFactValue(Node node)
	{
	node.getFirstChild().setNodeValue(node.getFirstChild().getNodeValue().trim());
	}

    private static String getFactKey(Node node)
	{
	return String.format("%s|%s", node.getNodeName(), getContextRef(node));
	}

    private static boolean isFact(Node node)
	{
	return node.getAttributes() != null && node.getAttributes().getNamedItem("contextRef") != null;
	}

    private static String getContextRef(Node node)
	{
	return node.getAttributes().getNamedItem("contextRef").getNodeValue();
	}

    }
