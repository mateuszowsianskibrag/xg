package api.service.processor.handler;

import java.util.HashSet;
import java.util.Set;

import api.model.exception.CustomRuntimeException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingErrorHandler;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingException;

public class SheetMappingErrorHandlerImpl implements SheetMappingErrorHandler {
    private static final Logger logger = LoggerFactory.getLogger(SheetMappingErrorHandlerImpl.class);
    private Set<String> errorList = new HashSet<String>();

    @Override
    public void warning(SheetMappingException ex) {
        logger.warn(ex.getMessage());
    }

    @Override
    public void message(String message) {
        logger.info(message);
    }

    @Override
    public void fatalError(SheetMappingException ex) {
        logger.error("FATAL: " + ex.getMessage());
        errorList.add("FATAL: " + ex.getMessage());
    }

    @Override
    public void error(SheetMappingException e) {
        logger.error("ERROR: " + e.getMessage());
        String msg = e.getMessage();
        errorList.add("ERROR: " + msg);
        if ("Element declaration '{' not found.".equals(msg)) {
            throw new CustomRuntimeException("problem");
        }
    }

    public Set<String> getErrorList() {
        return errorList;
    }

    public void setErrorList(Set<String> errorList) {
        this.errorList = errorList;
    }
}
