package api.service.processor.v2;

import api.model.xbrl.XBRLXLSXInstance;
import api.model.xbrl.XBRLXMLInstance;
import api.service.processor.DuplicatedFactsCleanerHelper;
import api.service.processor.UnitCleanerHelper;
import api.service.processor.handler.SheetMappingErrorHandlerImpl;
import api.service.processor.handler.XBRLErrorHandlerImpl;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingException;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingProcessor;
import com.fujitsu.xml.xbrl.xwand.instance.Instance;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessor;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessorException;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.SetUtils;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;
import java.io.IOException;
import java.util.Set;

@Slf4j
public class Xlsx2XmlInstanceConverter implements IXBRLConverter<XBRLXLSXInstance, XBRLXMLInstance, XBRLXMLInstance>{

    public static Xlsx2XmlInstanceConverter of(XBRLProcessor xbrlProcessor){
        return new Xlsx2XmlInstanceConverter(xbrlProcessor);
    }
    private final XBRLProcessor xbrlProcessor;

    public Xlsx2XmlInstanceConverter(XBRLProcessor xbrlProcessor) {
        this.xbrlProcessor = xbrlProcessor;
    }

    @Override
    public XBRLXMLInstance convert(XBRLXLSXInstance xlsxInstance, String mappingPath) throws XBRLProcessorException, IOException, SAXException, SheetMappingException {


        long startingTime = System.currentTimeMillis();
        SheetMappingErrorHandlerImpl sheetMappingErrorHandlerImpl = new SheetMappingErrorHandlerImpl();
        XBRLErrorHandlerImpl xbrlErrorHandler = FujitsuXBRLProcessor.setErrorHandler(xbrlProcessor);
        log.info("Loading template instance: " + xlsxInstance.templateInstancePath());
        Instance templateInstance = xbrlProcessor.loadInstance(xlsxInstance.createStreamSource());

        log.info("Creating an instance of SheetMappingProcessor");
        SheetMappingProcessor sheetMappingProcessor = FujitsuXlsxProcessor.createNewInstance(sheetMappingErrorHandlerImpl, mappingPath);

        try {
            sheetMappingProcessor.process(xlsxInstance.inputFilePath(), templateInstance);
            log.info("Generating file: {} in {} ", xlsxInstance.outputFilePath(), (System.currentTimeMillis() - startingTime) / 1000);
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        Set<String> errors = SetUtils.union(xbrlErrorHandler.getErrorList(), sheetMappingErrorHandlerImpl.getErrorList());
        return XBRLXMLInstance.newXbrlInstance(templateInstance, errors);
    }

    @Override
    public Set<String> save(XBRLXMLInstance xbrlxmlInstance, String outputFilePath) throws IOException, ParserConfigurationException, TransformerException, SAXException, XBRLProcessorException {

        Instance instance = xbrlxmlInstance.xbrlInstance();
        instance.setSystemId(outputFilePath);
        xbrlProcessor.setOutputProperty(OutputKeys.INDENT, "yes");
        xbrlProcessor.saveInstance(instance, new StreamResult(outputFilePath));

        UnitCleanerHelper.cleanUnusedUnits(outputFilePath);
        DuplicatedFactsCleanerHelper.cleanDuplicatedFacts(outputFilePath);

        return xbrlxmlInstance.errors();
    }
}
