package api.service.processor;

public final class XBRLInstanceFilename {

    private XBRLInstanceFilename() {}

    public static String changeToXbrlIfNeeded(String instanceFilename) {

        boolean existsInstance = instanceFilename != null && !instanceFilename.isEmpty();
        if(!existsInstance) {
            return instanceFilename;
        }

        int lastDotIndex = instanceFilename.lastIndexOf('.');
        if (lastDotIndex == -1) {
            // If there's no extension, just add ".xbrl" at the end
            return instanceFilename + ".xbrl";
        }

        // Otherwise, replace the existing extension with ".xbrl"
        return instanceFilename.substring(0, lastDotIndex) + ".xbrl";
    }
}
