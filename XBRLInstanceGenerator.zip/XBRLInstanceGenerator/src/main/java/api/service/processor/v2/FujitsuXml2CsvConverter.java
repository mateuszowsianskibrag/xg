package api.service.processor.v2;

import com.fujitsu.xbrl.oim.converter.xml2csv.XML2CSVConverter;
import com.fujitsu.xbrl.oim.converter.xml2csv.XML2CSVConverterOptions;
import com.fujitsu.xbrl.oim.csv.metadata.model.Metadata;

final class FujitsuXml2CsvConverter {

    private FujitsuXml2CsvConverter() {}

    public static XML2CSVConverter createNewInstance(Metadata metadata) {
        XML2CSVConverterOptions options = XML2CSVConverterOptions.createNewOptions();
        return new XML2CSVConverter(metadata, options);
    }
}
