package api.service.processor;

import api.config.XBRLInstanceConverterConfig;
import api.model.xbrl.XBRLCSVInstance;
import api.model.xbrl.XBRLXLSXInstance;
import api.model.xbrl.XBRLXMLInstance;
import api.service.EntityResolverService;
import api.service.processor.v2.FujitsuXBRLProcessor;
import api.service.processor.v2.Xlsx2XmlInstanceConverter;
import api.service.processor.v2.Xml2CsvInstanceConverter;
import com.fujitsu.xbrl.oim.converter.xml2csv.exception.XML2CSVConversionException;
import com.fujitsu.xbrl.oim.csv.exception.ParametersCSVCreationException;
import com.fujitsu.xbrl.oim.processor.exception.OIMProcessorException;
import com.fujitsu.xml.xbrl.custom.exception.XBRLLoadingException;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingException;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessor;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessorException;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashSet;
import java.util.Set;

/**
 * Service class for the functionalities offered by XWand API
 *
 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
 */
@Slf4j
@Service("processorService")
public class ProcessorService {

    @Autowired
    private EntityResolverService entityResolverService;

    @Autowired
    private XBRLInstanceConverterConfig xbrlInstanceConverterConfig;
    private XBRLProcessor xbrlProcessor;

    @PostConstruct
    private XBRLProcessor getXbrlProcessoar() {
        try {
            xbrlProcessor = FujitsuXBRLProcessor.createNewInstance(entityResolverService);
        } catch (XBRLProcessorException e) {
            log.error(e.getMessage());
        }
        return xbrlProcessor;
    }


    public synchronized Set<String> generateCSVXBRLInstance(String inputFilePath, String outputFilePath,
                                                            String mappingFilePath, String templateInstancePath, String uriMappingPath) throws XBRLProcessorException, SheetMappingException, IOException, SAXException, URISyntaxException, XBRLLoadingException, ParametersCSVCreationException, ParserConfigurationException, OIMProcessorException, XML2CSVConversionException, TransformerException, OIMProcessorException, ParametersCSVCreationException {


        XBRLXLSXInstance xbrlxlsxInstance = XBRLXLSXInstance.of(templateInstancePath, outputFilePath, inputFilePath);
        Xlsx2XmlInstanceConverter xlsx2XmlInstanceConverter = Xlsx2XmlInstanceConverter.of(xbrlProcessor);
        XBRLXMLInstance xbrlxmlInstance = xlsx2XmlInstanceConverter.convert(xbrlxlsxInstance, mappingFilePath);
        log.info("Conversion to XML just finished successfully");
        Set<String> messages  = new HashSet<>();

        if(xbrlxmlInstance == null){
            messages.add("Conversion to XML failed");
            return messages;
        }

        messages.addAll(xbrlxmlInstance.errors());

        try{
            Xml2CsvInstanceConverter xml2CsvInstanceConverter = new Xml2CsvInstanceConverter();
            XBRLCSVInstance xbrlcsvInstance = xml2CsvInstanceConverter.convert(xbrlxmlInstance, uriMappingPath);
            log.info("Conversion to CSV just finished");

            Set<String> messagesCreatedDuringSavingInstance = xml2CsvInstanceConverter.save(xbrlcsvInstance, outputFilePath);
            messages.addAll(messagesCreatedDuringSavingInstance);

            return messages;

        }catch (Exception e){

            log.error("conversion to CSV just finished failure", e);
            if(xbrlInstanceConverterConfig.canSaveIntermediateInstanceIfError()){
                Set<String> conversionMessages = xlsx2XmlInstanceConverter.save(xbrlxmlInstance, XBRLInstanceFilename.changeToXbrlIfNeeded(outputFilePath));
                messages.addAll(conversionMessages);
            }

            return messages;

        }finally {
            System.gc();
        }

    }

    public synchronized Set<String> generateXBRLInstance(String inputFilePath, String outputFilePath, String mappingFilePath, String templateInstancePath) throws Exception {

        XBRLXLSXInstance xbrlxlsxInstance = new XBRLXLSXInstance(templateInstancePath, outputFilePath, inputFilePath, new HashSet<>());
        Xlsx2XmlInstanceConverter instanceConverter = Xlsx2XmlInstanceConverter.of(xbrlProcessor);
        XBRLXMLInstance xbrlxmlInstance = instanceConverter.convert(xbrlxlsxInstance, mappingFilePath);
        Set<String> messages = instanceConverter.save(xbrlxmlInstance, outputFilePath);

        System.gc();

        return messages;
    }
}
