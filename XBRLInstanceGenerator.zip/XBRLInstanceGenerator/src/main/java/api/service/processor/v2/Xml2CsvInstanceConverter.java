package api.service.processor.v2;


import api.model.xbrl.XBRLCSVInstance;
import api.model.xbrl.XBRLXMLInstance;
import com.fujitsu.xml.xbrl.custom.exception.XBRLLoadingException;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessorException;

import lombok.extern.slf4j.Slf4j;
import com.fujitsu.xbrl.oim.converter.xml2csv.XML2CSVConverter;
import com.fujitsu.xbrl.oim.converter.xml2csv.utils.InstanceUtils;
import com.fujitsu.xbrl.oim.csv.exception.ParametersCSVCreationException;
import com.fujitsu.xbrl.oim.csv.metadata.model.Metadata;
import com.fujitsu.xbrl.oim.csv.metadata.parameters.ParametersCSV;
import com.fujitsu.xbrl.oim.csv.metadata.parameters.crator.ParametersCSVCreator;
import com.fujitsu.xbrl.oim.csv.metadata.parameters.crator.eba.SimpleEBAParametersCSVCreator;
import com.fujitsu.xbrl.oim.processor.OIMProcessor;
import com.fujitsu.xbrl.oim.processor.exception.OIMProcessorException;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Map;
import java.util.Set;

@Slf4j
public class Xml2CsvInstanceConverter implements IXBRLConverter<XBRLXMLInstance, XBRLCSVInstance, XBRLCSVInstance>{


    private final OIMProcessor oimProc;
    public Xml2CsvInstanceConverter() {
        this.oimProc = FujitsuOIMProcessor.createNewInstance();
    }

    @Override
    public XBRLCSVInstance convert(XBRLXMLInstance xbrlxmlInstance, String mappingPath) throws URISyntaxException, ParserConfigurationException, IOException, SAXException, OIMProcessorException, XBRLLoadingException, ParametersCSVCreationException {
        String entryPointJson = InstanceUtils.getEntryPointJson(xbrlxmlInstance.xbrlInstance());

        Map<String, String> prefixNamespaceMapping = null;
        FujitsuOIMProcessor.setXBRLEntityResolver(oimProc, mappingPath);
        prefixNamespaceMapping = oimProc.loadMetadata(entryPointJson).getDocumentInfo().getPrefixNamespaceMapping();

        ParametersCSVCreator paramCSVCreator = new SimpleEBAParametersCSVCreator(
                xbrlxmlInstance.createDimensionalInstance(),
                prefixNamespaceMapping
        );
        ParametersCSV parametersCSV = paramCSVCreator.create();
        Metadata metadata = oimProc.loadMetadata(entryPointJson, parametersCSV);

        return XBRLCSVInstance.newXbrlInstance(xbrlxmlInstance.xbrlInstance(), metadata);
    }

    @Override
    public Set<String> save(XBRLCSVInstance XBRLCSVInstance, String outputFilePath) throws IOException, ParserConfigurationException, TransformerException, SAXException, XBRLProcessorException {

        if(XBRLCSVInstance == null){
            throw new XBRLProcessorException("CSV XBRL Instance cannot be null");
        }

        try(FileOutputStream outputStream = new FileOutputStream(outputFilePath)) {
            XML2CSVConverter xml2CSVConv = FujitsuXml2CsvConverter.createNewInstance(XBRLCSVInstance.metadata());
            xml2CSVConv.convert(XBRLCSVInstance.xbrlInstance(), outputStream);
            outputStream.flush();

        } catch (Exception e) {
            XBRLCSVInstance.addError(e.getMessage());
            log.error(ExceptionUtils.getStackTrace(e));
        }

        return XBRLCSVInstance.errors();
    }
}
