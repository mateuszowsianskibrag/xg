package api.service.processor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

public class AbstractXBRLHelper
    {

    protected static Document readXMLDocument(String filePath) throws SAXException, IOException, ParserConfigurationException
	{
	File xmlFile = new File(filePath);
	DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
	return documentBuilder.parse(xmlFile);
	}

    protected static void normalizeDocument(Node xbrlNode)
	{
	xbrlNode.getOwnerDocument().getDocumentElement().normalize();
	for (int i = 0; i < xbrlNode.getChildNodes().getLength(); i++)
	    {
	    Node node = xbrlNode.getChildNodes().item(i);
	    if (node.getNodeValue() != null && node.getNodeValue().startsWith("\n"))
		{
		xbrlNode.removeChild(node);
		}
	    }
	}

    protected static void writeToXMLFile(Document document, String outputFilePath) throws IOException, TransformerException
	{
	DOMSource source = new DOMSource(document);
	FileOutputStream fileOutputStream = new FileOutputStream(new File(outputFilePath));
	StreamResult result = new StreamResult(new OutputStreamWriter(fileOutputStream, StandardCharsets.UTF_8.name()));

	TransformerFactory transformerFactory = TransformerFactory.newInstance();
	Transformer transformer = transformerFactory.newTransformer();
	transformer.setOutputProperty(OutputKeys.ENCODING, StandardCharsets.UTF_8.name());
	transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

	transformer.transform(source, result);
	fileOutputStream.close();
	}

    }