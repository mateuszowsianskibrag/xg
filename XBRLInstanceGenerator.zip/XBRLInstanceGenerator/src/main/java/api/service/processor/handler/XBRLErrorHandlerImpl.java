package api.service.processor.handler;

import com.fujitsu.xml.xbrl.xwand.processor.XBRLErrorHandler;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.Set;

public class XBRLErrorHandlerImpl implements XBRLErrorHandler {
    private static final Logger logger = LoggerFactory.getLogger(XBRLErrorHandlerImpl.class);
    private Set<String> errorList = new HashSet<String>();

    @Override
    public void fatalError(XBRLProcessorException e) {
        logger.error("FATAL: " + e.getMessage(), e);
        errorList.add("FATAL: " + e.getMessage());
    }

    @Override
    public void error(XBRLProcessorException e) {
        logger.error("ERROR: " + e.getMessage());
        errorList.add("ERROR: " + e.getMessage());
    }

    @Override
    public void warning(XBRLProcessorException e) {
        logger.warn(e.getMessage());
    }

    @Override
    public void message(XBRLProcessorException e) {
        logger.debug(e.getMessage());
    }

    public Set<String> getErrorList() {
        return errorList;
    }
}
