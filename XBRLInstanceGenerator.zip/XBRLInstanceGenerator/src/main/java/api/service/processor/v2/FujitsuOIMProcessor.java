package api.service.processor.v2;

import com.fujitsu.xbrl.oim.csv.report.resolver.CSVXBRLEntityResolver;
import com.fujitsu.xbrl.oim.processor.OIMProcessor;
import com.fujitsu.xbrl.oim.processor.OIMProcessorFactory;
import com.fujitsu.xbrl.oim.processor.OIMProcessorOption;
import com.fujitsu.xbrl.oim.processor.OIMProcessorOptionFactory;
import com.fujitsu.xml.xbrl.custom.resolver.urimapping.URIMappingEntityResolver;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLEntityResolver;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;

public final class FujitsuOIMProcessor {

    private FujitsuOIMProcessor() {}

    public static OIMProcessor createNewInstance(){

        // Initialize OIM Processor
        OIMProcessorOptionFactory oimProcOptionFactory = OIMProcessorOptionFactory.newInstance();
        OIMProcessorOption oimProcOption = oimProcOptionFactory.newOIMProcessorOption();

        OIMProcessorFactory oimProcFactory = OIMProcessorFactory.newInstance();
        return oimProcFactory.newOIMProcessor(oimProcOption);
    }

    public static void setXBRLEntityResolver(OIMProcessor oimProc, String uriMappingPath) throws ParserConfigurationException, IOException, SAXException {

        XBRLEntityResolver entityResolver = new URIMappingEntityResolver(uriMappingPath);
        oimProc.setCSVEntityResolver(new CSVXBRLEntityResolver(entityResolver));

    }
}
