package api.service.processor.v2;

import api.model.xbrl.IXBRLInstance;
import com.fujitsu.xbrl.oim.csv.exception.ParametersCSVCreationException;
import com.fujitsu.xbrl.oim.processor.exception.OIMProcessorException;
import com.fujitsu.xml.xbrl.custom.exception.XBRLLoadingException;
import com.fujitsu.xml.xbrl.sheetmapping.SheetMappingException;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessorException;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Set;

public interface IXBRLConverter<XBRL_INSTANCE_INPUT extends IXBRLInstance, XBRL_INSTANCE_OUTPUT extends IXBRLInstance, XBRL_TYPE extends IXBRLInstance> {


    XBRL_INSTANCE_OUTPUT convert(XBRL_INSTANCE_INPUT xbrlInstance, String mappingPath) throws XBRLProcessorException, IOException, SAXException, SheetMappingException, URISyntaxException, ParserConfigurationException, OIMProcessorException, XBRLLoadingException, ParametersCSVCreationException;
    Set<String> save(XBRL_TYPE xbrlInstance, String outputFilePath) throws IOException, ParserConfigurationException, TransformerException, SAXException, XBRLProcessorException;
}
