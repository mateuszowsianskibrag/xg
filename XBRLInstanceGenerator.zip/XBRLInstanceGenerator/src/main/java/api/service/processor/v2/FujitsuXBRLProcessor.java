package api.service.processor.v2;

import api.service.processor.handler.XBRLErrorHandlerImpl;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLEntityResolver;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessor;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProcessorException;
import com.fujitsu.xml.xbrl.xwand.processor.XBRLProperties;

public final class FujitsuXBRLProcessor {

    private FujitsuXBRLProcessor() {}

    public static XBRLProcessor createNewInstance(XBRLEntityResolver xbrlEntityResolver) throws XBRLProcessorException {

        XBRLProcessor xbrlProc = new XBRLProcessor();
        xbrlProc.setProperty(XBRLProperties.PERFORM_SCHEMA_VALIDATION, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.PROCESS_CALCULATION_LINK, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.CHECK_CALCULATION, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.CHECK_DUPLICATE_ITEM_TUPLE, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.CHECK_ID_ATTR_DECL, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.CHECK_ITEM_CONSISTENCY, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.CHECK_NETWORK_CYCLES, XBRLProperties.NO);
        xbrlProc.setProperty(XBRLProperties.VALIDATE_TUPLE_CONTENT, XBRLProperties.NO);
        //process/validate Extensible Enumerations
        xbrlProc.setProperty(XBRLProperties.PROCESS_EXT_ENUM, XBRLProperties.YES);

        xbrlProc.setEntityResolver(xbrlEntityResolver);

        return xbrlProc;
    }

    public static XBRLErrorHandlerImpl setErrorHandler(XBRLProcessor xbrlProc) {

        XBRLErrorHandlerImpl xbrlErrorHandler = new XBRLErrorHandlerImpl();
        xbrlProc.setErrorHandler(xbrlErrorHandler);

        return xbrlErrorHandler;
    }
}
