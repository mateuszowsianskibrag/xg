package api.controller;

public abstract class BaseController
    {

    }
