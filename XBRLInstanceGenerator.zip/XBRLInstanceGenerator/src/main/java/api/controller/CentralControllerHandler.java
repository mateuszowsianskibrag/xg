package api.controller;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import api.model.response.ApiError;

/**
 * Central controller class for exception management
 * 
 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
 * 
 */
@ControllerAdvice
public class CentralControllerHandler
    {
    final static private Logger logger = LoggerFactory.getLogger(CentralControllerHandler.class);

    @ExceptionHandler({ BindException.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public ApiError bindException(BindException e, Locale locale)
        {
	List<ObjectError> allErrors = e.getAllErrors();
	ObjectError error = allErrors.get(0);

	logger.error("{}: {}", e.getClass().getName(), e.getMessage());

	return new ApiError(StringUtils.substringBefore(error.getDefaultMessage(), "|"), StringUtils.substringAfter(error.getDefaultMessage(), "|"));
	}

    @ExceptionHandler({ FileNotFoundException.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public ApiError exception(FileNotFoundException e, Locale locale)
        {
	logger.error("{}: {}", e.getClass().getName(), e.getMessage());
	return new ApiError(e.getMessage(), "ERR_FILE_NOT_FOUND");
	}

    @ExceptionHandler({ Exception.class })
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    public ApiError exception(Exception e, Locale locale)
        {
	logger.error("{}: {}", e.getClass().getName(), e.getMessage());
	return new ApiError(e.getClass().getName() + ": " + e.getMessage(), "ERR_SERVER");
	}

    }
