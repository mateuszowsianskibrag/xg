package api.controller;

import api.model.request.CSVInstanceGeneratorRequest;
import api.model.request.InstanceGeneratorRequest;
import api.model.response.InstanceGeneratorResponse;
import api.service.processor.ProcessorService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.Set;

/**
 * Class implementing the API services related to instance generation
 *
 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
 */
@RestController
public class InstanceGeneratorController {

    private final ProcessorService processorService;
    public InstanceGeneratorController(ProcessorService processorService) {
        this.processorService = processorService;
    }

    /**
     * Generating XBRL instance from the given data
     *
     * @param instanceGeneratorRequest
     * @return
     * @throws Exception
     * @last_modification: May 8, 2014
     * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
     */
    @PostMapping(value ="/GenerateXblrXmlInstance")
    @ResponseStatus(value = HttpStatus.OK)
    public InstanceGeneratorResponse generateInstance(@Valid @RequestBody InstanceGeneratorRequest instanceGeneratorRequest) throws Exception {
        Set<String> errorMessages = processorService.generateXBRLInstance(
                instanceGeneratorRequest.getInputFilePath(), instanceGeneratorRequest.getOutputFilePath(),
                instanceGeneratorRequest.getMappingFilePath(), instanceGeneratorRequest.getTemplateInstancePath()
        );

        return InstanceGeneratorResponse.of(errorMessages);
    }

    @PostMapping(value ="/GenerateXblrCSVInstance")
    @ResponseStatus(value = HttpStatus.OK)
    public InstanceGeneratorResponse generateCSVInstance(@Valid @RequestBody CSVInstanceGeneratorRequest instanceGeneratorRequest) throws Exception {

        Set<String> errorMessages = processorService.generateCSVXBRLInstance(
                instanceGeneratorRequest.getInputFilePath(), instanceGeneratorRequest.getOutputFilePath(),
                instanceGeneratorRequest.getMappingFilePath(), instanceGeneratorRequest.getTemplateInstancePath(),
                instanceGeneratorRequest.getUriMappingFilePath()
        );

        return InstanceGeneratorResponse.of(errorMessages);
    }
}
