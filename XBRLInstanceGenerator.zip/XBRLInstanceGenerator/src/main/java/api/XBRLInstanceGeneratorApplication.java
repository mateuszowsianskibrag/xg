package api;

import api.config.LicenseConfig;
import api.config.XBRLInstanceConverterConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@EnableConfigurationProperties({LicenseConfig.class, XBRLInstanceConverterConfig.class})
@SpringBootApplication
public class XBRLInstanceGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(XBRLInstanceGeneratorApplication.class, args);
    }

}
