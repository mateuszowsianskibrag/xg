package api.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.Map;

/**
 * Header request authorization filter
 * 
 * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
 * 
 */
public class ApiAuthFilter implements Filter
    {
    private static final String validToken = "4sWLcNNkSxxD0SdPlW";

    @Override
    public void init(FilterConfig filterConfig) throws ServletException
        {
	}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
	    throws IOException,
	    ServletException
        {
	doFilter((HttpServletRequest) request, (HttpServletResponse) response, filterChain);
	}

    protected void doFilter(HttpServletRequest request, HttpServletResponse response,
	    FilterChain filterChain)
	    throws IOException, ServletException
        {
	// check header
	String authHeader = getAuthHeader(request);

	// check query string
	if (StringUtils.isEmpty(authHeader))
	    {
	    authHeader = getFromQueryString(request);
	    }

	if (!isValid(authHeader))
	    {
	    response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
	    return;
	    }

	filterChain.doFilter(request, response);
	}

    @Override
    public void destroy()
        {
	}

    // helpers
    private boolean isValid(String authHeader)
        {
	if (!StringUtils.isEmpty(authHeader))
	    {
	    return validToken.equals(authHeader);
	    }

	return false;
	}

    private String getFromQueryString(HttpServletRequest request)
        {
	Map<String, String[]> parameterMap = request.getParameterMap();
	String[] tokenList = parameterMap.get("token");

	if (tokenList != null && tokenList.length > 0)
	    {
	    return tokenList[0];
	    }

	return null;
	}

    private String getAuthHeader(HttpServletRequest request)
        {
	return request.getHeader("Authorization");
	}

    }
