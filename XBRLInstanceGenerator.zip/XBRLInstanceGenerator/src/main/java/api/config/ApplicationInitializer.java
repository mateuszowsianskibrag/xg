package api.config;

import api.filter.ApiAuthFilter;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRegistration;
import org.mortbay.servlet.GzipFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

public class ApplicationInitializer implements WebApplicationInitializer {
    final static private Logger logger = LoggerFactory.getLogger(ApplicationInitializer.class);
    final static private String MAIN_PACKAGE = "api";
    private static AnnotationConfigWebApplicationContext rootContext;

    @Override
    public void onStartup(final ServletContext servletContext) throws ServletException {
        logger.debug("onStartup");

        // Load application context
        initRootContext();

        // Add context loader listener
        initDefaultListeners(servletContext);

        // default
        initDefaultServlet(servletContext, "defaultDispatcher");

        // Adding filters
        initFilters(servletContext);
    }

    protected static AnnotationConfigWebApplicationContext initRootContext() {
        if (rootContext == null) {
            logger.debug("init root api context");
            rootContext = new AnnotationConfigWebApplicationContext();
            rootContext.setDisplayName("api");
            rootContext.scan(MAIN_PACKAGE);
        } else {
            logger.debug("skip init root api context");
        }

        return rootContext;
    }

    protected void initDefaultListeners(ServletContext servletContext) {
        logger.debug("init default listeners");
//	servletContext.addListener(new Log4jConfigListener());
        servletContext.addListener(new ContextLoaderListener(rootContext));
        servletContext.addListener(new RequestContextListener());
    }

    protected void initDefaultServlet(ServletContext servletContext, String servletName) {
        if (servletContext.getServletRegistration(servletName) == null) {
            logger.debug("init default servlet: {}", servletName);
            final ServletRegistration.Dynamic defaultDispatcher = (ServletRegistration.Dynamic) servletContext.addServlet(servletName, String.valueOf(new DispatcherServlet(rootContext)));
            defaultDispatcher.addMapping("/*");
            defaultDispatcher.setLoadOnStartup(1);

        } else {
            logger.debug("skip init default servlet: {} - already registered", servletName);
        }
    }

    protected void initFilters(ServletContext servletContext) {
        servletContext.addFilter("authorizationFilter", ApiAuthFilter.class).addMappingForUrlPatterns(null, false, "/*");
//			servletContext.addFilter("GzipFilter", GzipFilter.class).addMappingForUrlPatterns(null, false, "/*");
    }


}
