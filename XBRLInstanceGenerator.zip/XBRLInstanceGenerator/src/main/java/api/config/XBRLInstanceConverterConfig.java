package api.config;

import api.model.XBRLInstanceSaveOptions;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties("xbrlinstance.converter")
public record XBRLInstanceConverterConfig(XBRLInstanceSaveOptions saveOption) {

    public boolean canSaveIntermediateInstanceIfError() {
        return saveOption == XBRLInstanceSaveOptions.SAVE_INTERMEDIATE_IF_ERROR;
    }
}
