package api.config;

import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableAspectJAutoProxy
@EnableWebMvc
public class InterceptorConfiguration implements WebMvcConfigurer {

    @Bean
    public TraceInterceptor interceptor()
        {
	final TraceInterceptor interceptor = new TraceInterceptor();
	interceptor.setEnterMessage("Entering $[methodName]($[arguments]).");
	interceptor.setExitMessage("Leaving $[methodName]() with return value $[returnValue], took $[invocationTime]ms.");

	return interceptor;
	}

    @Bean
    public Advisor traceAdvisor()
        {
	final AspectJExpressionPointcut pointcut = new
		AspectJExpressionPointcut();
	pointcut.setExpression("execution(* api.controller.*.*(..))");

	return new DefaultPointcutAdvisor(pointcut, interceptor());
	}
    }
