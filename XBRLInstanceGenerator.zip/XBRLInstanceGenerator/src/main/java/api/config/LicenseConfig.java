package api.config;

import lombok.extern.java.Log;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.nio.file.Path;

@Log
@ConfigurationProperties("lic")
public record LicenseConfig(String path) {

    public FileInputStream createInputStream() throws FileNotFoundException {
        if(path == null)
            throw new FileNotFoundException("License file not found");

        return new FileInputStream(path);
    }
}
