package api.config;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

//@Configuration
public class PropertiesConfig
    {

    /**
     * Setting location of properties files
     * 
     * @last_modification: May 5, 2014
     * @author Ricardo Rodriguez <ricardo.rodriguez.castro@br-ag.eu>
     * @return
     */
    @Bean
    public PropertyPlaceholderConfigurer propertiesConfigurer()
        {
	PropertyPlaceholderConfigurer propertiesConfigurer = new PropertyPlaceholderConfigurer();
	propertiesConfigurer.setLocations(new ClassPathResource[] { new ClassPathResource("taxonomyRepositorySettings.properties") });
	propertiesConfigurer.setIgnoreUnresolvablePlaceholders(true);
	return propertiesConfigurer;
	}
    }
