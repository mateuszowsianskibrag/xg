package api.config;

import com.fujitsu.xml.xbrl.custom.license.LicenseManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class FujitsuLicenseInitializer {


    public FujitsuLicenseInitializer(LicenseConfig licenseConfig) {
        try {
            LicenseManager.setLicense(licenseConfig.createInputStream());
            log.info("License loaded successfully");
            if (!LicenseManager.isLoaded()) {
                throw new IllegalStateException("License is not loaded");
            }

        } catch (Exception e) {
            throw new IllegalStateException("Error loading license", e);
        }
    }

}
