package api.config;

import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.logging.Log;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.aop.interceptor.CustomizableTraceInterceptor;

import api.controller.BaseController;
import api.model.request.BaseRequest;
import api.model.response.ApiError;

public class TraceInterceptor extends CustomizableTraceInterceptor
    {
    private static final long serialVersionUID = -7946027875658228422L;
    private static final Logger logger = LoggerFactory.getLogger(TraceInterceptor.class);

    @Override
    protected String replacePlaceholders(String message, final MethodInvocation methodInvocation,
	    final Object returnValue, final Throwable throwable, long invocationTime)
        {
	if (methodInvocation.getThis() instanceof BaseController && (returnValue != null || throwable != null))
	    {
	    Thread t = new Thread()
	        {
		    @Override
		    public void run()
		        {
			BaseRequest request = (methodInvocation.getArguments().length > 0) ? (BaseRequest) methodInvocation.getArguments()[0] : null;
			// Success
			if (returnValue != null)
			    {
			    logger.info("Service [{}], Request [{}], Return [{}]", new Object[] { methodInvocation.getMethod().getName(), request, returnValue.toString() });
			    }
			// Error
			else if (throwable != null)
			    {
			    ApiError apiError = new ApiError(throwable.getMessage(), throwable.getClass().getName());
			    logger.info("Service [{}], Request [{}], ApiError [{}]", new Object[] { methodInvocation.getMethod().getName(), request.toString(), apiError.toString() });
			    }
			}
		};
	    t.start();
	    }
	return super.replacePlaceholders(message, methodInvocation, returnValue, throwable, invocationTime);
	}

    @Override
    protected boolean isInterceptorEnabled(MethodInvocation invocation, Log logger)
        {
	return true;
	}
    }