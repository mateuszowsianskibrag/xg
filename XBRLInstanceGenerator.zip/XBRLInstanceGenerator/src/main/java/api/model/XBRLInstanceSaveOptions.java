package api.model;

public enum XBRLInstanceSaveOptions {

    ONLY_TARGET,
    SAVE_INTERMEDIATE_IF_ERROR

}
