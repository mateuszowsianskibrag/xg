package api.model.xbrl;

import com.fujitsu.xbrl.oim.csv.metadata.model.Metadata;
import com.fujitsu.xml.xbrl.xwand.instance.Instance;

import java.util.HashSet;
import java.util.Set;

public record XBRLCSVInstance(Instance xbrlInstance, Metadata metadata, Set<String> errors) implements IXBRLInstance {

    public static XBRLCSVInstance newXbrlInstance(Instance xbrlInstance, Metadata metadata) {
        return new XBRLCSVInstance(xbrlInstance, metadata, new HashSet<>());
    }
    public void addError(String error) {
        errors.add(error);
    }
}
