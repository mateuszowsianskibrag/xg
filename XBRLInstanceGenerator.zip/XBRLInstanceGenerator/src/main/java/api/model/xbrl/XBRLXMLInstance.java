package api.model.xbrl;

import com.fujitsu.xml.xbrl.custom.exception.XBRLLoadingException;
import com.fujitsu.xml.xbrl.custom.loading.DimensionalLoader;
import com.fujitsu.xml.xbrl.dimension.instance.DimensionalInstance;
import com.fujitsu.xml.xbrl.xwand.instance.Instance;

import java.util.Set;

public record XBRLXMLInstance(Instance xbrlInstance, Set<String> errors) implements IXBRLInstance {

    public static XBRLXMLInstance newXbrlInstance(Instance xbrlInstance, Set<String> errors) {
        return new XBRLXMLInstance(xbrlInstance, errors);
    }

    public DimensionalInstance createDimensionalInstance() throws XBRLLoadingException {
        return new DimensionalLoader().createDimensionalInstance(xbrlInstance);
    }

    public void addError(String error) {
        errors.add(error);
    }
}
