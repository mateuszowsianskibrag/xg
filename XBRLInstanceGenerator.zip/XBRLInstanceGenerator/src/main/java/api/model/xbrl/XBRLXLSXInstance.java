package api.model.xbrl;

import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import java.util.HashSet;
import java.util.Set;

public record XBRLXLSXInstance(String templateInstancePath, String outputFilePath, String inputFilePath, Set<String> errors) implements IXBRLInstance {

    public static XBRLXLSXInstance of(String templateInstancePath, String outputFilePath, String inputFilePath) {
        return new XBRLXLSXInstance(templateInstancePath, outputFilePath, inputFilePath, new HashSet<>());
    }
    public Source createStreamSource() {
        return new StreamSource(templateInstancePath);
    }

    @Override
    public void addError(String error) {
        errors.add(error);
    }
}
