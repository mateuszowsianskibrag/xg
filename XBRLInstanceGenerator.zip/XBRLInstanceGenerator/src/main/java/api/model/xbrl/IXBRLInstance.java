package api.model.xbrl;

public interface IXBRLInstance {

    void addError(String error);
}
