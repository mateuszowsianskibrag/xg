package api.model.response;

public record ApiError(String errorMessage, String errorCode) implements BaseResponse {

    @Override
    public String toString() {
        return "errorMessage: " + errorMessage + ", errorCode: " + errorCode;
    }

    public boolean isSuccess() {
        return false;
    }

}