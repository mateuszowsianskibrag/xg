package api.model.response;

import java.util.Set;

public record InstanceGeneratorResponse(boolean success, Set<String> errorMessages) implements BaseResponse {

	public static InstanceGeneratorResponse of(Set<String> errorMessages) {
		return new InstanceGeneratorResponse(true, errorMessages);
	}
}
