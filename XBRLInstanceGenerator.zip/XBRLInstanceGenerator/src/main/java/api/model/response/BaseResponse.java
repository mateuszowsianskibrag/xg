package api.model.response;

interface BaseResponse {}
