package api.model.request;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CSVInstanceGeneratorRequest extends InstanceGeneratorRequest {
    private String uriMappingFilePath;
}
