package api.model.request;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotBlank;

@Setter
@Getter
public class InstanceGeneratorRequest extends BaseRequest {
    @NotBlank(message = "ERR_NO_INPUT_FILE|Invalid value for required param: inputFilePath")
    private String inputFilePath;
    @NotBlank(message = "ERR_NO_MAPPING_FILE|Invalid value for required param: mappingFilePath")
    private String mappingFilePath;
    @NotBlank(message = "ERR_NO_TEMPLATE_INSTANCE_FILE|Invalid value for required param: templateInstancePath")
    private String templateInstancePath;
    @NotBlank(message = "ERR_NO_INPUT_FILE|Invalid value for required param: outputFilePath")
    private String outputFilePath;
}
