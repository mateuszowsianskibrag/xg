package api.model.request;

public abstract class BaseRequest
    {

    }
